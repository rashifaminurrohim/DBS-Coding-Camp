const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  ACCESS_TOKEN_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJ1c2VyLTZxRHYzLXhZX3VncXFPangiLCJpYXQiOjE3NDYyNDE5OTV9.wQcW-taCQT9oQqPEUUP2NnUMvdNAGiAjqvVM1caW0j8',
};

export default CONFIG;
