async function startup() {
  function populateTakenPicture(image) {
    // TODO: show taken picture
  }

  function getStream() {
    // TODO: generate camera stream
  }

  function cameraLaunch(stream) {
    // TODO: launch camera on video
  }

  function cameraTakePicture() {
    // TODO: draw video frame to canvas
  }

  function init() {
    // TODO: init
  }

  init();
}

window.onload = startup;
